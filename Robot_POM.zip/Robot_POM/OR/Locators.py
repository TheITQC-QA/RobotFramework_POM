#Login Page Element

txt_UserName = "name:UserName"
txt_Password = "name=Password"
btn_Login = "name=Login"

#User form Elements 

drp_Title = "name:TitleId"
txt_Initial = "xpath://*[@id='Initial']"
txt_FirstName = "xpath://*[@id='FirstName']"
txt_MidName = "xpath://*[@id='MiddleName']"
rdo_Gender = "name:Male"
chk_Lang1 = "name:english"
btn_Save = "xpath://*[@id='details']/table/tbody/tr[7]/td/input"

#Mune Bar 
lnk_logout = "xpath://*[@id=cssmenu]/ul/li[1]/a"


#Registration Form
